from django.apps import AppConfig


class DemoProjConfig(AppConfig):
    name = 'demo_proj'
